import{E as m}from"./external-link-CC5-kE4X.js";import"./iframe-DO3T59VR.js";import"./preload-helper-BDBacUwf.js";import"./index-Cm7o6AEv.js";import"./utils-pBtDpbI-.js";import"./external-link-Bj3PA-Pk.js";const L={component:m,title:"Core/External link"},r={args:{url:"https://www.ebi.ac.uk/",children:"external link",noIcon:!1,tidyUrl:!1}},e={args:{...r.args,children:void 0}},n={args:{...r.args,url:null}};var a,t,s;r.parameters={...r.parameters,docs:{...(a=r.parameters)==null?void 0:a.docs,source:{originalSource:`{
  args: {
    url: 'https://www.ebi.ac.uk/',
    children: 'external link',
    noIcon: false,
    tidyUrl: false
  }
}`,...(s=(t=r.parameters)==null?void 0:t.docs)==null?void 0:s.source}}};var o,l,i;e.parameters={...e.parameters,docs:{...(o=e.parameters)==null?void 0:o.docs,source:{originalSource:`{
  args: {
    ...ExternalLink.args,
    children: undefined
  }
}`,...(i=(l=e.parameters)==null?void 0:l.docs)==null?void 0:i.source}}};var c,p,u;n.parameters={...n.parameters,docs:{...(c=n.parameters)==null?void 0:c.docs,source:{originalSource:`{
  args: {
    ...ExternalLink.args,
    url: null
  }
}`,...(u=(p=n.parameters)==null?void 0:p.docs)==null?void 0:u.source}}};const f=["ExternalLink","ExternalLinkWithoutPassingText","ExternalLinkWithNullUrl"];export{r as ExternalLink,n as ExternalLinkWithNullUrl,e as ExternalLinkWithoutPassingText,f as __namedExportsOrder,L as default};
