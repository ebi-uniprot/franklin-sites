import{r as c,j as p}from"./iframe-DO3T59VR.js";import{S as n}from"./search-input-Dk7lL7fc.js";import"./preload-helper-BDBacUwf.js";import"./search-Dr5lIa5D.js";import"./spinner-Cm4nS40_.js";import"./times-DfnBol28.js";const v={title:"Forms/Search Input"},e=()=>{const[s,o]=c.useState("");return p.jsx(n,{placeholder:"Search",value:s,onChange:u=>o(u.target.value)})};var r,t,a;e.parameters={...e.parameters,docs:{...(r=e.parameters)==null?void 0:r.docs,source:{originalSource:`() => {
  const [value, setValue] = useState('');
  return <SI placeholder="Search" value={value} onChange={e => setValue(e.target.value)} />;
}`,...(a=(t=e.parameters)==null?void 0:t.docs)==null?void 0:a.source}}};const x=["SearchInput"];export{e as SearchInput,x as __namedExportsOrder,v as default};
