import{r as c,j as p}from"./iframe-CjE16azO.js";import{S as n}from"./search-input-DE_ob4Tx.js";import"./preload-helper-BDBacUwf.js";import"./search-CbUEalDV.js";import"./spinner-DCrUSRBH.js";import"./times-4ovsui3U.js";const v={title:"Forms/Search Input"},e=()=>{const[s,o]=c.useState("");return p.jsx(n,{placeholder:"Search",value:s,onChange:u=>o(u.target.value)})};var r,t,a;e.parameters={...e.parameters,docs:{...(r=e.parameters)==null?void 0:r.docs,source:{originalSource:`() => {
  const [value, setValue] = useState('');
  return <SI placeholder="Search" value={value} onChange={e => setValue(e.target.value)} />;
}`,...(a=(t=e.parameters)==null?void 0:t.docs)==null?void 0:a.source}}};const x=["SearchInput"];export{e as SearchInput,x as __namedExportsOrder,v as default};
