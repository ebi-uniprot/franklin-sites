import{o as e}from"./preload-helper-BKhVKv2_.js";import{t}from"./iframe-BE2qzWq5.js";var n,r,i,a,o,s;e((()=>{n=t(),a={title:`Core/Colours`},o=()=>(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h1`,{children:`Colours`}),(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h2`,{children:`Primary palette`}),(0,n.jsx)(`div`,{className:`box-colour colour-sapphire-blue`,"data-name":`$colour-sapphire-blue`}),(0,n.jsx)(`div`,{className:`box-colour colour-sea-blue`,"data-name":`$colour-sea-blue`}),(0,n.jsx)(`div`,{className:`box-colour colour-vivid-cerulean`,"data-name":`$colour-vivid-cerulean`}),(0,n.jsx)(`div`,{className:`box-colour colour-medium-turquoise`,"data-name":`$colour-medium-turquoise`}),(0,n.jsx)(`div`,{className:`box-colour colour-gainsborough`,"data-name":`$colour-gainsborough`})]}),(0,n.jsx)(`hr`,{}),(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h2`,{children:`Grey Palette`}),(0,n.jsx)(`div`,{className:`box-colour colour-yankees-blue`,"data-name":`$colour-yankees-blue`}),(0,n.jsx)(`div`,{className:`box-colour colour-independence`,"data-name":`$colour-independence`}),(0,n.jsx)(`div`,{className:`box-colour colour-weldon-blue`,"data-name":`$colour-weldon-blue`}),(0,n.jsx)(`div`,{className:`box-colour colour-pastel-blue`,"data-name":`$colour-pastel-blue`}),(0,n.jsx)(`div`,{className:`box-colour colour-platinum`,"data-name":`$colour-platinum`}),(0,n.jsx)(`div`,{className:`box-colour colour-sky-white`,"data-name":`$colour-sky-white`})]}),(0,n.jsx)(`hr`,{}),(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h2`,{children:`Curation palette`}),(0,n.jsx)(`div`,{className:`box-colour colour-reviewed`,"data-name":`$colour-reviewed`}),(0,n.jsx)(`div`,{className:`box-colour colour-unreviewed`,"data-name":`$colour-unreviewed`})]}),(0,n.jsx)(`hr`,{}),(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h2`,{children:`Namespace palette`}),(0,n.jsx)(`div`,{className:`box-colour colour-uniref`,"data-name":`$colour-uniref`}),(0,n.jsx)(`div`,{className:`box-colour colour-uniparc`,"data-name":`$colour-uniparc`}),(0,n.jsx)(`div`,{className:`box-colour colour-proteomes`,"data-name":`$colour-proteomes`})]}),(0,n.jsx)(`hr`,{}),(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h2`,{children:`Help palette`}),(0,n.jsx)(`div`,{className:`box-colour colour-help-green`,"data-name":`$colour-help-green`})]}),(0,n.jsx)(`hr`,{}),(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h2`,{children:`Tools palette`}),(0,n.jsx)(`div`,{className:`box-colour colour-peptide-search`,"data-name":`$colour-peptide-search`}),(0,n.jsx)(`div`,{className:`box-colour colour-id-mapping`,"data-name":`$colour-id-mapping`}),(0,n.jsx)(`div`,{className:`box-colour colour-blast`,"data-name":`$colour-blast`}),(0,n.jsx)(`div`,{className:`box-colour colour-align`,"data-name":`$colour-align`})]}),(0,n.jsx)(`hr`,{}),(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h2`,{children:`Messages`}),(0,n.jsx)(`div`,{className:`box-colour colour-warning`,"data-name":`$colour-warning`}),(0,n.jsx)(`div`,{className:`box-colour colour-failure`,"data-name":`$colour-failure`}),(0,n.jsx)(`div`,{className:`box-colour colour-success`,"data-name":`$colour-success`}),(0,n.jsx)(`div`,{className:`box-colour colour-info`,"data-name":`$colour-info`})]}),(0,n.jsx)(`hr`,{}),(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h2`,{children:`Data visualisation`}),(0,n.jsx)(`div`,{className:`box-colour colour-coyote-brown`,"data-name":`$colour-coyote-brown`}),(0,n.jsx)(`div`,{className:`box-colour colour-outer-space`,"data-name":`$colour-outer-space`})]}),(0,n.jsx)(`hr`,{}),(0,n.jsxs)(`section`,{children:[(0,n.jsx)(`h2`,{children:`Variables`}),(0,n.jsxs)(`ul`,{children:[(0,n.jsxs)(`li`,{children:[(0,n.jsx)(`code`,{children:`$colour-link`}),`: the colour of something clickable`]}),(0,n.jsxs)(`li`,{children:[(0,n.jsx)(`code`,{children:`$colour-selected`}),`: the colour of something "active" or "selected"`]}),(0,n.jsxs)(`li`,{children:[(0,n.jsx)(`code`,{children:`$colour-hover`}),`: the colour of something selectable on mouse hover`]})]})]})]}),o.parameters={...o.parameters,docs:{...(r=o.parameters)==null?void 0:r.docs,source:{originalSource:`() => <section>
    <h1>Colours</h1>
    <section>
      <h2>Primary palette</h2>
      <div className="box-colour colour-sapphire-blue" data-name="$colour-sapphire-blue" />
      <div className="box-colour colour-sea-blue" data-name="$colour-sea-blue" />
      <div className="box-colour colour-vivid-cerulean" data-name="$colour-vivid-cerulean" />
      <div className="box-colour colour-medium-turquoise" data-name="$colour-medium-turquoise" />
      <div className="box-colour colour-gainsborough" data-name="$colour-gainsborough" />
    </section>
    <hr />
    <section>
      <h2>Grey Palette</h2>
      <div className="box-colour colour-yankees-blue" data-name="$colour-yankees-blue" />
      <div className="box-colour colour-independence" data-name="$colour-independence" />
      <div className="box-colour colour-weldon-blue" data-name="$colour-weldon-blue" />
      <div className="box-colour colour-pastel-blue" data-name="$colour-pastel-blue" />
      <div className="box-colour colour-platinum" data-name="$colour-platinum" />
      <div className="box-colour colour-sky-white" data-name="$colour-sky-white" />
    </section>
    <hr />
    <section>
      <h2>Curation palette</h2>
      <div className="box-colour colour-reviewed" data-name="$colour-reviewed" />
      <div className="box-colour colour-unreviewed" data-name="$colour-unreviewed" />
    </section>
    <hr />
    <section>
      <h2>Namespace palette</h2>
      <div className="box-colour colour-uniref" data-name="$colour-uniref" />
      <div className="box-colour colour-uniparc" data-name="$colour-uniparc" />
      <div className="box-colour colour-proteomes" data-name="$colour-proteomes" />
    </section>
    <hr />
    <section>
      <h2>Help palette</h2>
      <div className="box-colour colour-help-green" data-name="$colour-help-green" />
    </section>
    <hr />
    <section>
      <h2>Tools palette</h2>
      <div className="box-colour colour-peptide-search" data-name="$colour-peptide-search" />
      <div className="box-colour colour-id-mapping" data-name="$colour-id-mapping" />
      <div className="box-colour colour-blast" data-name="$colour-blast" />
      <div className="box-colour colour-align" data-name="$colour-align" />
    </section>
    <hr />
    <section>
      <h2>Messages</h2>
      <div className="box-colour colour-warning" data-name="$colour-warning" />
      <div className="box-colour colour-failure" data-name="$colour-failure" />
      <div className="box-colour colour-success" data-name="$colour-success" />
      <div className="box-colour colour-info" data-name="$colour-info" />
    </section>
    <hr />
    <section>
      <h2>Data visualisation</h2>
      <div className="box-colour colour-coyote-brown" data-name="$colour-coyote-brown" />
      <div className="box-colour colour-outer-space" data-name="$colour-outer-space" />
    </section>
    <hr />
    <section>
      <h2>Variables</h2>
      <ul>
        <li>
          <code>$colour-link</code>: the colour of something clickable
        </li>
        <li>
          <code>$colour-selected</code>: the colour of something
          &quot;active&quot; or &quot;selected&quot;
        </li>
        <li>
          <code>$colour-hover</code>: the colour of something selectable on
          mouse hover
        </li>
      </ul>
    </section>
  </section>`,...(i=o.parameters)==null||(i=i.docs)==null?void 0:i.source}}},s=[`Colours`]}))();export{o as Colours,s as __namedExportsOrder,a as default};