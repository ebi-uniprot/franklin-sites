import{g as r}from"./iframe-DO3T59VR.js";import{r as o}from"./index-BAB0HRAE.js";var t=o();const m=r(t);export{m as R,t as r};
