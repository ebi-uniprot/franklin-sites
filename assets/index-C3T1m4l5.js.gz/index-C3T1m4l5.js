import{g as r}from"./iframe-CjE16azO.js";import{r as o}from"./index-BNDnymhP.js";var t=o();const m=r(t);export{m as R,t as r};
