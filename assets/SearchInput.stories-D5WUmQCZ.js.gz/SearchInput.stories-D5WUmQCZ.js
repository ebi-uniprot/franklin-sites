import{r as c,j as p}from"./iframe-PpvKiT-0.js";import{S as n}from"./search-input-BhaYGf1x.js";import"./preload-helper-BDBacUwf.js";import"./search-RYX60C5I.js";import"./spinner-Bjf0vNEr.js";import"./times-BXb4cK5T.js";const v={title:"Forms/Search Input"},e=()=>{const[s,o]=c.useState("");return p.jsx(n,{placeholder:"Search",value:s,onChange:u=>o(u.target.value)})};var r,t,a;e.parameters={...e.parameters,docs:{...(r=e.parameters)==null?void 0:r.docs,source:{originalSource:`() => {
  const [value, setValue] = useState('');
  return <SI placeholder="Search" value={value} onChange={e => setValue(e.target.value)} />;
}`,...(a=(t=e.parameters)==null?void 0:t.docs)==null?void 0:a.source}}};const x=["SearchInput"];export{e as SearchInput,x as __namedExportsOrder,v as default};
