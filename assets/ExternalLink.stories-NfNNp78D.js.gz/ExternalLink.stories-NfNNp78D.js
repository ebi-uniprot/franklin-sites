import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{n as t,t as n}from"./external-link-CNayDuQC.js";var r,i,a,o,s,c,l,u,d,f,p;function m(){return(m=e((()=>{t(),l={component:n,title:`Core/External link`},u={args:{url:`https://www.ebi.ac.uk/`,children:`external link`,noIcon:!1,tidyUrl:!1}},d={args:{...u.args,children:void 0}},f={args:{...u.args,url:null}},p=[`ExternalLink`,`ExternalLinkWithoutPassingText`,`ExternalLinkWithNullUrl`],u.parameters={...u.parameters,docs:{...(r=u.parameters)==null?void 0:r.docs,source:{originalSource:`{
  args: {
    url: 'https://www.ebi.ac.uk/',
    children: 'external link',
    noIcon: false,
    tidyUrl: false
  }
}`,...(i=u.parameters)==null||(i=i.docs)==null?void 0:i.source}}},d.parameters={...d.parameters,docs:{...(a=d.parameters)==null?void 0:a.docs,source:{originalSource:`{
  args: {
    ...ExternalLink.args,
    children: undefined
  }
}`,...(o=d.parameters)==null||(o=o.docs)==null?void 0:o.source}}},f.parameters={...f.parameters,docs:{...(s=f.parameters)==null?void 0:s.docs,source:{originalSource:`{
  args: {
    ...ExternalLink.args,
    url: null
  }
}`,...(c=f.parameters)==null||(c=c.docs)==null?void 0:c.source}}}})))()}m();export{u as ExternalLink,f as ExternalLinkWithNullUrl,d as ExternalLinkWithoutPassingText,p as __namedExportsOrder,l as default};