import{g as r}from"./iframe-PpvKiT-0.js";import{r as o}from"./index-CBmz5ziX.js";var t=o();const m=r(t);export{m as R,t as r};
