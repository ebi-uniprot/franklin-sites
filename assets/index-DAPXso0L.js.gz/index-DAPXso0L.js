import{g as r}from"./iframe-BhWvmy2K.js";import{r as o}from"./index-cvDdTPII.js";var t=o();const m=r(t);export{m as R,t as r};
